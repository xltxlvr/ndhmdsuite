## 수식 미리보기 

\[ \frac{dy}{dx} = \frac{dy}{dt}\cdot \frac{dt}{dx} \]

<!--TAGS: #책예제 -->