---
setup: articlelike.nmd
title: Markdown으로 \LaTeX\ 원고 작성 
author: "Nova de Hi \\and Nonamë"
date: 2025년 11월 11일 -- 2026년 8월 15일
classoption: b5, 11pt
toplevel: section
preamble+: |
  \usepackage{amsmath}
  \ifpdftex
    \let\grfoo\relax
    \usepackage{mathpazo}
  \else\ifLuaOrXeTeX
    \usepackage[rubystyle=rup,expos]{grruby}
  \fi\fi
  \AtBeginEnvironment{quote}{\small\setstretch{1.2}}{}{}
---

\maketitle

:::{abstract}
  이 글은 원래 pandoc을 위해 작성한 것이었다.
  *ndhmarkdown*으로 번역하고 테스트한다.
  편집은 Visual Studio Code로 하였다.
:::

<!-- 첫 문서 작성 -->

# 전제 {#sec:prel}

잊지 말아야 할 대전제 하나를 확인하고 시작하자. \grfoo 언명(言明)하면 다음과 같다. 

:::{center}
:::{boxedminipage raw="{\dimeval{\textwidth-3em}}\centering"}
\LaTeX 은 **조판 프로그램**이고, *Markdown*은 **글쓰기 도구**이다.
:::
:::

우리가 \LaTeX{} 문서를 작성할 때 포함하는 마크업에는 조판적 요소가 들어 있다. 예를 들면 어떤 행과 행 사이를 얼마간 띄운다든가, 한 행의 Overfull을 처리하기 위하여 추가적인 표지를 붙인다든가 하는 것이 그런 종류의 것이다.

반면 *Markdown*은 단지 글쓰기, 즉 내용을 채우는 도구일 뿐이다. 내가 생각하기에 *Markdown*이 성공할 수 있었던 가장 중요한 점은 그 *단순성*이다. 다른 요소를 일절 배제하고 오직 텍스트만을 생산하는 데 이보다 더 좋은 도구는 없다.

*Markdown* 작성된 글은, 따라서, \LaTeX 을 통하여 PDF 출력을 얻을 때에 약간의 후처리, 즉 미세조절이 필요한 경우도 있다. 그러나 그것은 어디까지나 "후처리"일 뿐이다. 

# 어떤 종류의 글을 주로 쓰는가

이것은 매우 중요한 질문이다. 만약 주로 쓰는 글이 수필이나 소설과 같이 텍스트만으로 이루어진 것이라면 별달리 보충할 것이 없다. 대부분의 경우 결과는 *만족할 만*할 것이다.

여행기 같이 그림이 많은 글이라고 해도, *Markdown*으로 만들어진 원고를 \LaTeX{} 변환하여 적절한 결과를 얻을 수 있다.

# 문서에 포함되는 요소

## 그림

\LaTeX 에서 우리는 소스에 직접 코드를 삽입하여 그림을 얻을 수 있다. Ti*k*Z, asymptote, METAPOST 등이 그것을 가능하게 해준다.

*Markdown*으로 글쓰기할 때라면, 그림은 외부에서 작성하는 것이 좋다. 그 그림은 이미지일 수도 있고 Ti*k*Z로 작성된 것일 수도 있다.

![Test Image](figures/sNRNR.png){place=htbp,scale=.5,label="fig:A"}

가볍게 그림을 삽입하였다. 이 그림은 `figure` 환경 안에 놓인다. 인라인 이미지는 ![](figures/sNRNR.png){height=12pt,raise=-3pt}.

## 상호참조

[F:fig:A]\는 이 그림을 참조하는 코드이다. 앞서, [#sec:prel]절 "[title:sec:prel]"에서 말한 바와 같이, 중요한 것은 
무엇을 쓰는가, 인 것이다.

## 도표

기본 '파이프' 표기의 *booktabs* 표를 제공한다. 반드시 heading행이 있어야 하는 것이 중요하다.

:::{table label=tbl:sample,place=htbp,caption="테스트 테이블"}
| 이름  | 주소 |
|:-----:|:-----:|
| 성춘향 | 남원골 |
| 이몽룡 | 한양   |
:::

만약 표~[#tbl:sample]에서 힌트를 발견하였다면 다행이겠다. 간단한 표는 이와 같이 처리할 수 있다. 
원한다면 \LaTeX{} *tabular* 소스 코드를 그대로 박아넣어도 된다.

```showexam 
\begin{tabular}{cc}
\hline 
이름 & 주소 \\ \hline 
성춘향 & 남원골 \\
이몽룡 & 한양 \\ \hline 
\end{tabular}
```

***

요즘 각광받는 `tabularray`를 연계하는 문제는 "T/B/L/R 도우미"의
도움을 얻도록 하자. 해당 앱이 생산한 코드를 그대로 붙여넣기한다.

# 수식

수식의 처리는 매우 쉽다. \LaTeX 에서와 동일하게 `$`를 이용하면 된다. 예컨대, \(e^{ix}=i\sin x+\cos x\).
이 식에서 $i$는 허수단위($i=\sqrt{-1}$)이다.
그리고 별행수식은 
\begin{equation}
\frac{dy}{dx}=\frac{dy}{du}\cdot\frac{du}{dx} \label{eq:test}
\end{equation}
와 같이 쓰면 된다. 여러 줄 수식은 amsmath의 `alianged` 같은 환경을 쓸 수도 있다.
\begin{align}
a &= b+c \\
  &= f+g \label{eq:testii}
\end{align}

이와 같이 amsmath의 여러 줄 수식 환경을 직접 코딩해도 된다. ([#eq:test])\과 ([#eq:testii])\이 그렇게 작성된 것이다.

참고로, 레퍼런스는 \LaTeX{} 명령을 그대로 써도 잘 구현된다: "식 ([#eq:testii])\을{} 참고하면 좋다."

# 문단 간

소설 따위를 쓰다가 보면 문단 사이에 뭔가를 넣어야 할 때가 있다.
\LaTeX 에서 문단 사이에 두는 간격은 `\bigskip`, `\medskip`, `\smallskip`이 있는데,
이것을 그대로 쓸 수 있는가?

***

되는 것인지를 테스트하였다. 잘 된다. 훌륭하다.

한편, asterism이라고 하는 것을 넣을 수 있다. `memoir`에 있는 `\fancybreak`를 응용할 수도 있다.

\fancybreak{* * *}

\noindent 이 정도면 간단한 asterism으로 대용할 수 있을 것이다. 더 화려한 asterism 구분표를 만드는 것은 얼마든지 허용될 것이다.

---

# 따옴표

키보드 따옴표(스트레이트 따옴표)를 입력하면 \LaTeX{}  변환시에 \TeX{} 따옴표로 자동 변환이 이루어진다.

> "따옴표"를 입력한다. '작은 따옴표'와 "큰 따옴표" 뒤에 조사가 붙어도
> 안전하게 처리된다. 예외적으로 여는 따옴표가 정확하게 나타나지 않으면 
> ``\verb|\`\`|``{=latex}와 같이 입력할 수 있다.


<!--TAGS: #단독 -->