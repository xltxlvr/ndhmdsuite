---
title: ndhmdWriter 작업 환경 
author: A. U. Thor
date: 2026년 9월
classoption+: chapter 
toplevel: chapter
mappingrule+: |
  mdash: '\expldash '
  asterism: '\fancybreak{* * *}'
maketitle: true
preamble+: |
  \usepackage[dbl4x6]{fapapersize}

  %% Maths
  \usepackage{amsmath,amsthm}
  \newtheorem{theorem}{정리}[section]
  \newtheorem{lemma}[theorem]{보조정리}

  %% 사용자 정의
  \NewDocumentEnvironment{boxedt}{O{}}{%
    \noindent\fbox{\textsf{\small\bfseries #1}}:%
  }{}
  \ifx\expldash\undefined\let\expldash\textemdash\fi
  \makefootrule{ruled}{\textwidth}{.4pt}{\footruleskip}

  \usepackage{ksvqt}
  \usepackage[export]{adjustbox}
  \usepackage{wrapstuff}

  %% 글꼴
  \iftutex
    %%% 한글 폰트 선언을 mathfont 이후에 (progress)
    \setkomainfont(Noto Serif CJK KR)
    \setkosansfont(Noto Sans CJK KR)
    \usepackage{ksjosaref}
    \AtBeginDocument{\josarefcmds}
  \fi

  %% 메이크인덱스
  \makeindex
compileoption: --makeindex='komkindex -k -s kotex'
graphicspath: ["./","figures/"]
---

<!--TAGS: #책예제 #메인 -->

{{frontmatter_samplebook.md}}
